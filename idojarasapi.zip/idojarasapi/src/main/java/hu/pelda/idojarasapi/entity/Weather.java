/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hu.pelda.idojarasapi.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

/**
 *
 * @author barna
 */
@Entity
@Table(name="weather")
public class Weather {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    
    @Column(name="city")
    private String city;
    
    @Column(name="date")
    private LocalDate date;
    
    @Column(name="temperature")
    private Double temperature;
    
    @Column(name="humidity")
    private Integer humidity;
    
    @Column(name="wind_speed")
    private Double windSpeed;

    public Integer getId() {
        return id;
    }

    public String getCity() {
        return city;
    }

    public LocalDate getDate() {
        return date;
    }

    public Double getTemperature() {
        return temperature;
    }

    public Integer getHumidity() {
        return humidity;
    }

    public Double getWindSpeed() {
        return windSpeed;
    }
    
    
}
