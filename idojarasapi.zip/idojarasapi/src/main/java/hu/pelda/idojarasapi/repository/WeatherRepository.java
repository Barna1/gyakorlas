/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hu.pelda.idojarasapi.repository;

import hu.pelda.idojarasapi.entity.Weather;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author barna
 */
public interface WeatherRepository extends JpaRepository<Weather, Integer>{
    Optional<Weather> findTopByCityIgnoreCaseOrderByDateDesc(String city); //top=legfelső, orderbydatedesc=csökkenő, ezek miatt a legfrissebbet adja vissza
    
    List<Weather> findByCityIgnoreCaseAndDateBetweenOrderByDateDesc(
            String city,
            LocalDate start,
            LocalDate end
    );
}
