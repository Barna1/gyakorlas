/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filmekapp;

import java.time.LocalDate;

/**
 *
 * @author barna
 */
public class Film {
    int FilmId;
    String Cim;
    String Mufaj;
    int HosszPerc;
    LocalDate BemutatoDatum;
    int Korhatar;
    double Ertekeles;
    int Elerheto;
}
