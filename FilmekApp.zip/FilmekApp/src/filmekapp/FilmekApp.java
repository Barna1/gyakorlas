/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package filmekapp;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author barna
 */
public class FilmekApp {

    /**
     * @param args the command line arguments
     */
    static List<Film> lista = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        //2. feladat
        BufferedReader br = new BufferedReader(new FileReader("filmek.txt"));
        br.readLine();

        String sor;
        while ((sor = br.readLine()) != null) {
            String[] m = sor.split(";");

            Film film = new Film();
            film.FilmId = Integer.parseInt(m[0]);
            film.Cim = m[1];
            film.Mufaj = m[2];
            film.HosszPerc = Integer.parseInt(m[3]);
            film.BemutatoDatum = LocalDate.parse(m[4]);
            film.Korhatar = Integer.parseInt(m[5]);
            film.Ertekeles = Double.parseDouble(m[6]);
            film.Elerheto = Integer.parseInt(m[7]);

            lista.add(film);
        }
        br.close();
        //3.feladat
        System.out.println("3. feladat, " + "\nFilmek szama: " + lista.size());

        //4.feladat
        int elerheto = 0;
        for (Film f : lista) {
            if (f.Elerheto == 1) {
                elerheto++;
            }
        }
        System.out.println("4.feladat, " + "\nElerheto filmek szama: " + elerheto);

        // 5. feladat)
        int osszeg = 0;
        int db = 0;

        for (Film f : lista) {
            if (f.Elerheto == 1) {
                osszeg += f.HosszPerc;
                db++;
            }
        }
        int atlag = (db == 0) ? 0 : osszeg / db;

        System.out.println("5. feladat, Az elerheto filmek atlagos hossza: " + atlag + " perc");

        //6.feladat
        Film max = null;

        for (Film f : lista) {
            if (f.Mufaj.equals("SciFi")) {

                if (max == null || f.Ertekeles > max.Ertekeles) {
                    max = f;
                }
            }
        }
        System.out.println("6.feladat: " + "\nCim: " + max.Cim + " Bemutato datum: " + max.BemutatoDatum + " Ertekeles: " + max.Ertekeles);
        //7.feladat
        int vanE = 0;
        for (Film f : lista) {
            if ((f.Elerheto == 1) && (f.HosszPerc < 100) && (f.Ertekeles >= 7.0)) {
                vanE++;
                break;
            }
        }
        if (vanE > 0) {
            System.out.println("Van jo ertekelesu rovid vigjatek");
        }else{
            System.out.println("Nincs jo ertekelesu rovid vigjatek");
        }
        
    }

}
