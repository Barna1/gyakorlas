const varos = document.getElementById("varos");
const datum = document.getElementById("datum");
const result = document.getElementById("result");

const baseUrl = "http://localhost:8080/api/idojaras/";

async function getWeather() {
    if ((!varos.value.trim() && !datum.value) || (!varos.value.trim() && datum.value)) {

        let response = await fetch(baseUrl)
        console.log(response);

        let data = await response.json();
        console.log(data);

        result.innerHTML = JSON.stringify(data);
    } else if (!datum.value) {

        let response = await fetch(baseUrl + '?varos=' + varos.value.trim());
        console.log(response);

        let data = await response.json();
        console.log(data);

        result.innerHTML = JSON.stringify(data);
    } else {
        let response = await fetch(baseUrl + '?varos=' + varos.value.trim() + '&datum=' + datum.value);
        console.log(response);

        let data = await response.json();
        console.log(data);

        if (Array.isArray(data)) {
            let actualDay = data.filter(element => element.datum === datum.value);

            if (actualDay.length === 0) {
                result.innerHTML = '{"hiba": "Nincs találat!"}';
                return;
            }

            result.innerHTML = JSON.stringify(actualDay[0]);
        } else {
            result.innerHTML = JSON.stringify(data);
        }

        
    }
}