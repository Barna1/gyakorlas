package filmekdesktop;

import java.io.BufferedReader;
import java.io.FileReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class FilmekDesktop extends Application {

    static List<Film> lista = new ArrayList<>();

    @Override
    public void start(Stage stage) throws Exception {

        BufferedReader br = new BufferedReader(new FileReader("filmek.txt"));
        br.readLine();

        String sor;
        while ((sor = br.readLine()) != null) {
            String[] m = sor.split(";");

            Film f = new Film();
            f.FilmId = Integer.parseInt(m[0]);
            f.Cim = m[1];
            f.Mufaj = m[2];
            f.HosszPerc = Integer.parseInt(m[3]);
            f.BemutatoDatum = LocalDate.parse(m[4]);
            f.Korhatar = Integer.parseInt(m[5]);
            f.Ertekeles = Double.parseDouble(m[6]);
            f.Elerheto = Integer.parseInt(m[7]);

            lista.add(f);
        }

        br.close();

        Parent root = FXMLLoader.load(getClass().getResource("FilmekDesktop.fxml"));
        stage.setScene(new Scene(root));
        stage.setTitle("Filmek");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}