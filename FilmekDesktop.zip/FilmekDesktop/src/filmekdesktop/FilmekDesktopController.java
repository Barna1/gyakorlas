package filmekdesktop;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class FilmekDesktopController implements Initializable {

    @FXML private ComboBox<String> valasszonFilmet;

    @FXML private Label cimLabel;
    @FXML private Label mufajLabel;
    @FXML private Label hosszLabel;
    @FXML private Label datumLabel;
    @FXML private Label korhatarLabel;

    @FXML private CheckBox elerhetoCheckBox;
    @FXML private ProgressBar progressBar;
    @FXML private Slider ertekelesSlider;

    @FXML private Label ertekelesLabel;
    @FXML private Label progressLabel;

    int maxHossz = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // 1. COMBOBOX FELTÖLTÉS
        valasszonFilmet.getItems().add("Valasszon filmet!");
        valasszonFilmet.setValue("Valasszon filmet!");

        for (Film f : FilmekDesktop.lista) {
            valasszonFilmet.getItems().add(f.FilmId + " - " + f.Cim);
        }

        // 2. MAX HOSSZ KISZÁMOLÁS
        for (Film f : FilmekDesktop.lista) {
            if (f.HosszPerc > maxHossz) {
                maxHossz = f.HosszPerc;
            }
        }

        // 3. HA VÁLASZTASZ FILMET
        valasszonFilmet.setOnAction(e -> {

            String valasztas = valasszonFilmet.getValue();

            for (Film f : FilmekDesktop.lista) {

                String s = f.FilmId + " - " + f.Cim;

                if (s.equals(valasztas)) {

                    // LABEL-ek
                    cimLabel.setText("Cim: " + f.Cim);
                    mufajLabel.setText("Mufaj: " + f.Mufaj);
                    hosszLabel.setText("Hossz: " + f.HosszPerc + " perc");
                    datumLabel.setText("Datum: " + f.BemutatoDatum);
                    korhatarLabel.setText("Korhatar: " + f.Korhatar);

                    // CHECKBOX
                    elerhetoCheckBox.setDisable(true);
                    elerhetoCheckBox.setSelected(f.Elerheto == 1);

                    // PROGRESSBAR
                    double ratio = (double) f.HosszPerc / maxHossz;
                    progressBar.setProgress(ratio);

                    int percent = (int) (ratio * 100);
                    progressLabel.setText("A film a max " + percent + "%-a");

                    // SLIDER
                    ertekelesSlider.setMin(0);
                    ertekelesSlider.setMax(10);
                    ertekelesSlider.setValue(f.Ertekeles);

                    ertekelesLabel.setText("Ertekeles: " + f.Ertekeles + "/10");
                }
            }
        });

        // 4. SLIDER MOZGÁS KÖZBEN
        ertekelesSlider.valueProperty().addListener((obs, o, n) -> {
            ertekelesLabel.setText(String.format("Ertekeles: %.1f/10", n.doubleValue()));
        });
    }
}